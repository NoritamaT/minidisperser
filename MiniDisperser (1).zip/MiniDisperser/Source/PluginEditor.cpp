#include "PluginEditor.h"

DisperserEditor::DisperserEditor (DisperserProcessor& p) : AudioProcessorEditor (&p)
{
    setup (amount, p, "amount", "AMOUNT");
    setup (freq,   p, "freq",   "FREQUENCY");
    setup (pitch,  p, "pitch",  "PITCH");
    setSize (420, 220);
}

void DisperserEditor::setup (Knob& k, DisperserProcessor& p, const juce::String& id, const juce::String& name)
{
    k.slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 20);
    k.slider.setColour (juce::Slider::rotarySliderFillColourId, juce::Colour (0xff4fc3f7));
    k.slider.setColour (juce::Slider::thumbColourId, juce::Colours::white);
    addAndMakeVisible (k.slider);

    k.label.setText (name, juce::dontSendNotification);
    k.label.setJustificationType (juce::Justification::centred);
    k.label.setFont (juce::FontOptions (14.0f, juce::Font::bold));
    k.label.setColour (juce::Label::textColourId, juce::Colours::white.withAlpha (0.8f));
    addAndMakeVisible (k.label);

    k.attach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (p.apvts, id, k.slider);
}

void DisperserEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff1b1d23));
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (18.0f, juce::Font::bold));
    g.drawText ("DISPERSER", getLocalBounds().removeFromTop (36), juce::Justification::centred);
}

void DisperserEditor::resized()
{
    auto area = getLocalBounds().withTrimmedTop (36).reduced (10);
    const int w = area.getWidth() / 3;
    for (auto* k : { &amount, &freq, &pitch })
    {
        auto col = area.removeFromLeft (w);
        k->label.setBounds (col.removeFromTop (20));
        k->slider.setBounds (col);
    }
}
