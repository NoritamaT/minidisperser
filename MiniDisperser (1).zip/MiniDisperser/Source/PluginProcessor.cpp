#include "PluginProcessor.h"
#include "PluginEditor.h"

DisperserProcessor::DisperserProcessor()
    : AudioProcessor (BusesProperties()
          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    pAmount = apvts.getRawParameterValue ("amount");
    pFreq   = apvts.getRawParameterValue ("freq");
    pPitch  = apvts.getRawParameterValue ("pitch");
}

juce::AudioProcessorValueTreeState::ParameterLayout DisperserProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout l;

    l.add (std::make_unique<AudioParameterFloat> (
        ParameterID { "amount", 1 }, "Amount",
        NormalisableRange<float> (0.0f, 100.0f, 0.01f), 50.0f,
        AudioParameterFloatAttributes().withLabel ("%")));

    l.add (std::make_unique<AudioParameterFloat> (
        ParameterID { "freq", 1 }, "Frequency",
        NormalisableRange<float> (20.0f, 20000.0f, 0.01f, 0.3f), 1000.0f,
        AudioParameterFloatAttributes().withLabel ("Hz")));

    l.add (std::make_unique<AudioParameterFloat> (
        ParameterID { "pitch", 1 }, "Pitch",
        NormalisableRange<float> (-48.0f, 48.0f, 0.01f), 0.0f,
        AudioParameterFloatAttributes().withLabel ("st")));

    return l;
}

void DisperserProcessor::prepareToPlay (double sampleRate, int)
{
    sr = sampleRate;
    smAmount.reset (sr, 0.05); smAmount.setCurrentAndTargetValue (*pAmount);
    smFreq  .reset (sr, 0.05); smFreq  .setCurrentAndTargetValue (*pFreq);
    smPitch .reset (sr, 0.05); smPitch .setCurrentAndTargetValue (*pPitch);

    std::memset (z1, 0, sizeof (z1));
    std::memset (z2, 0, sizeof (z2));
}

bool DisperserProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    auto out = l.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo())
           && out == l.getMainInputChannelSet();
}

// 各ステージの中心周波数: freq * 2^(pitch/12 * k/maxStages)
// pitch が0なら全段同じ周波数、±にすると段ごとに周波数がずれていく
void DisperserProcessor::updateCoefficients (float freq, float pitchSemis)
{
    const float nyq = (float) sr * 0.45f;
    constexpr float Q = 0.7071f;

    for (int k = 0; k < maxStages; ++k)
    {
        float f = freq * std::pow (2.0f, (pitchSemis / 12.0f) * ((float) k / (float) maxStages));
        f = juce::jlimit (10.0f, nyq, f);

        const float w0    = juce::MathConstants<float>::twoPi * f / (float) sr;
        const float cosw  = std::cos (w0);
        const float alpha = std::sin (w0) / (2.0f * Q);
        const float a0inv = 1.0f / (1.0f + alpha);

        auto& c = coeffs[(size_t) k];
        c.b0 = (1.0f - alpha) * a0inv;
        c.b1 = -2.0f * cosw * a0inv;
        c.b2 = 1.0f;                      // (1+alpha)/(1+alpha)
        c.a1 = c.b1;
        c.a2 = c.b0;
    }
}

void DisperserProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numCh = juce::jmin (buffer.getNumChannels(), 2);
    const int n     = buffer.getNumSamples();

    smAmount.setTargetValue (*pAmount);
    smFreq  .setTargetValue (*pFreq);
    smPitch .setTargetValue (*pPitch);

    // ブロック単位で係数更新 (パラメータはスムージング済み)
    const float amount = smAmount.skip (n) * 0.01f;
    const float freq   = smFreq.skip (n);
    const float pitch  = smPitch.skip (n);
    updateCoefficients (freq, pitch);

    // Amount: 0〜100% → 0〜maxStages 段 (端数は最後の段をクロスフェード)
    const float stagesF = amount * (float) maxStages;
    const int   full    = (int) stagesF;
    const float frac    = stagesF - (float) full;

    for (int ch = 0; ch < numCh; ++ch)
    {
        float* x = buffer.getWritePointer (ch);
        float* s1 = z1[ch];
        float* s2 = z2[ch];

        for (int i = 0; i < n; ++i)
        {
            float v = x[i];

            for (int k = 0; k < full; ++k)
            {
                const auto& c = coeffs[(size_t) k];
                const float y = c.b0 * v + s1[k];
                s1[k] = c.b1 * v - c.a1 * y + s2[k];
                s2[k] = c.b2 * v - c.a2 * y;
                v = y;
            }

            if (full < maxStages && frac > 0.0f)
            {
                const auto& c = coeffs[(size_t) full];
                const float y = c.b0 * v + s1[full];
                s1[full] = c.b1 * v - c.a1 * y + s2[full];
                s2[full] = c.b2 * v - c.a2 * y;
                v += frac * (y - v);
            }

            x[i] = v;
        }
    }
}

juce::AudioProcessorEditor* DisperserProcessor::createEditor() { return new DisperserEditor (*this); }

void DisperserProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, dest);
}

void DisperserProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new DisperserProcessor(); }
