#pragma once
#include "PluginProcessor.h"

class DisperserEditor : public juce::AudioProcessorEditor
{
public:
    explicit DisperserEditor (DisperserProcessor&);
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct Knob
    {
        juce::Slider slider { juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::TextBoxBelow };
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attach;
    };

    void setup (Knob&, DisperserProcessor&, const juce::String& id, const juce::String& name);

    Knob amount, freq, pitch;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DisperserEditor)
};
